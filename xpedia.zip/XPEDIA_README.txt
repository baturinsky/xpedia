Copy this to the root directory of the game

Run xpedia.bat to construct and open xpedia.html

Or if you already has up-to-date xpedia.html you can just open it directly

If mod is *not* XPiratez, edit xpedia.bat to change mod's name