1. Copy this to the root directory of the game.

2. If you have Node.js installed, regardless of OS, run "node xpedia.js". Otherwise, if you are using Windows, run "xpedia.bat".
It will construct and open xpedia.html. Former option makes more compact file and is cross platform.

Or if you already has up-to-date xpedia.html you can just open it directly.

If mod is *not* XPiratez, edit xpedia.bat to change mod's name.